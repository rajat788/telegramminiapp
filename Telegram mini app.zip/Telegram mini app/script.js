// Initialize Telegram Mini App
let tg = window.Telegram.WebApp;
tg.expand(); // Expand the app to full view

// Function to Fetch Trending News
async function fetchNews() {
    const response = await fetch('https://newsapi.org/v2/top-headlines?country=us&apiKey=YOUR_NEWS_API_KEY');
    const data = await response.json();

    let newsHTML = "";
    data.articles.slice(0, 5).forEach(article => {
        newsHTML += `<p><strong>${article.title}</strong><br>${article.description}</p>`;
    });

    document.getElementById("news-container").innerHTML = newsHTML;
}

// Refresh News Button
document.getElementById("refresh").addEventListener("click", fetchNews);

// Fetch news when the app loads
fetchNews();
